import math

class Point:

    pass
    
class Vec2D(Point):

    pass

if __name__=='__main__':

    pass

